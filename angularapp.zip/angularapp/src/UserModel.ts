export class UserModel{
    userRole?:string;
	 email?:string;
	 username?:string;
	 mobileNumber?:string;
     password?:string;
}