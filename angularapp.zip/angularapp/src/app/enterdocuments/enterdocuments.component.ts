import { Component } from '@angular/core';

@Component({
  selector: 'app-enterdocuments',
  templateUrl: './enterdocuments.component.html',
  styleUrls: ['./enterdocuments.component.css']
})
export class EnterdocumentsComponent {

}
