export class UserModel{
    userid?:number;
    userRole?:string;
	 email?:string;
	 username?:string;
	 mobileNumber?:string;
     password?:string;
}