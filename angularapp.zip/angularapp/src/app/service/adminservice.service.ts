import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

 url ="http://localhost:8085/loan/viewLoan";
 constructor(private htt:HttpClient){}

 //geting loan list

 loan(){
  return this.htt.get(this.url);
 }

 approveurl = "http://localhost:8085/loan/approveloan";
 approvel(data:number){
  return this.htt.get(`${this.approveurl}/${data}`);
 }

 rejecturl = "http://localhost:8085/loan/rejectloan";
 rejectl(data:number){
  return this.htt.get(`${this.approveurl}/${data}`);
 }

 documenturl ="http://localhost:8085/document/upload/";
 upload(data:File,num:number){
  const formData: FormData = new FormData();

    formData.append('file', data);
  return this.htt.post(`${this.documenturl}${num}`,formData);
 }
}
